function PlotEnvelopandIntersection(EvInitial, Envelop, intery, interz, faultseedpoint, wellpickindex, wellpathlb, wellpathX, IntersectionX, flag_Envelop, flag_transparency)
% flag_Envelop��ʾ���������ͣ�flag_Envelop==0��ʾû��ʹ�þ����ݵ����ĳ�ʼ�����ߣ�flag_Envelop==1��ʾʹ�þ����ݵ�����İ�����
% flag_transparency��ʾ͸���ȵı�־��flag_transparency==0��ʾ�������ߵ�͸��������Ϊ0.3���ο��ϲ��͸��������Ϊ1��flag_transparenc==1��flag_transparency==0������ǡ���෴
num_yinter = size(intery,2);
num_zinter = size(intery,1);
strikeindex = faultseedpoint(:,1);   % �������Ӧ�Ķϲ�������
x_sample = faultseedpoint(:,2);      % �������x����
y_sample = faultseedpoint(:,3);      % �������y����
z_sample = faultseedpoint(:,4);      % �������z����
sampleX = [y_sample z_sample];       % �����������
sampleY = x_sample;                  % ����������
FaultRefer = 0.5 * (Envelop.up + Envelop.bl);
interx = reshape( FaultRefer, size(intery,2),size(intery,1) )';
% ͨ��ƽ�����ɵĶϲ�ʵ�ֵ�x���깹�ɵľ���
[invalidpointyindex,invalidpointzindex] = findinvalidinterpointindex(y_sample, z_sample, strikeindex, num_yinter, num_zinter);
%invalidpointyindex, invalidpointzindex��Ч�����������������������С�����д���ֵ����֮�������ȥ����
upenvelope = reshape(Envelop.up,size(intery,2),size(intery,1))';
blenvelope = reshape(Envelop.bl,size(intery,2),size(intery,1))';
for i = 1 : length(invalidpointzindex)
    interx(invalidpointzindex(i), invalidpointyindex(i)) = inf;
    upenvelope(invalidpointzindex(i), invalidpointyindex(i)) = inf;
    blenvelope(invalidpointzindex(i), invalidpointyindex(i)) = inf;
end
EvInitial.intersectionfault = 0.5 * (EvInitial.intersectionup + EvInitial.intersectionbl);
% ���ݳ�ʼ���������ɵĲο��ϲ�ĺ����
Envelop.intersectionfault = 0.5 * (Envelop.intersectionup + Envelop.intersectionbl);
%%
%��������ǻ��þ����ݵ�����İ����ߺ�һ���ϲ�ʵ�ֵ���άͼ�����а����ߵ�͸��������Ϊ0.3
figure;
% subfigure1 = subplot( 1, 3, 1 );%��ע�͵����ǽ�����ͼ����һ��ͼ�еĴ���
% set( subfigure1, 'Position', [0.241 0.15541 0.187 0.815]);
% set(gcf,'Units','centimeters','Position',[1 1 10 5]);
cdata = cat( 3, 1*ones(size(interx)), 0.498*ones(size(interx)), 0*ones(size(interx)) );%����ɫ
% cdata=cat( 3, 0.803921569*ones(size(interx)), 0.521568627*ones(size(interx)), 0.247058824*ones(size(interx)) );% ��³ɫ	
mid = surf(interx, intery, interz, cdata);
shading interp
hold on
if flag_Envelop == 0
%     cdata=cat( 3, 0.48235*ones(size(interx)), 0.40784*ones(size(interx)), 0.93333*ones(size(interx)) );%��ɫ 
%     cdata = cat( 3, 0.309803922*ones(size(interx)), 0.580392157*ones(size(interx)), 0.803921569*ones(size(interx)) );%SteelBlue3
    cdata = cat( 3, 0.51765*ones(size(interx)), 0.4392*ones(size(interx)), 1*ones(size(interx)) );
else
    cdata=cat( 3, 0*ones(size(interx)), 0.8078*ones(size(interx)), 0.8196*ones(size(interx)) );%����ʯɫ
%     cdata=cat( 3, 0.803921569*ones(size(interx)), 0.215686275*ones(size(interx)), 0*ones(size(interx)) ); % OrangeRed3
%     cdata=cat( 3, 0.603921569*ones(size(interx)), 0.803921569*ones(size(interx)), 0.196078431*ones(size(interx)) ); % OliveDrab3
end
up = surf(upenvelope, intery, interz, cdata);
hold on
if flag_Envelop ~= 0
    for i=1
        [wellpathx, wellpathy, wellpathz ] = sphere(200);
        wellpathx = wellpathx*20 + wellpathlb(i) + 10;
        wellpathy = wellpathy*30 + wellpathX(i,1);
        wellpathz = wellpathz*30 + wellpathX(i,2);
        cdata = cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );%����ɫ
        wpath = surf(wellpathx, wellpathy, wellpathz, cdata);%���ư뾶Ϊ2����
    end
end
hold on
if flag_Envelop ~= 0 & ~isempty(wellpickindex)
    for i=1
        [wellpickx, wellpicky, wellpickz] = sphere(200);
        wellpickx = wellpickx*20 + sampleY(wellpickindex(i));
        wellpicky = wellpicky*30 + sampleX(wellpickindex(i), 1);
        wellpickz = wellpickz*30 + z_sample(42);
        cdata = cat( 3, 0*ones(size(wellpickx)), 0*ones(size(wellpickx)), 0*ones(size(wellpickx)) );%����ɫ
        wpick = surf(wellpickx, wellpicky, wellpickz, cdata);%���ư뾶Ϊ2����
    end
end
shading interp
% legendposition=legend( 'a fault realization','The envelope adjusted by welldata','wellpath','wellpicks', 4 );
% set(legendposition,'Position', [0.295, 0.79, 0.08, 0.03])%����legendλ��
% set(legendposition,'Position', [0.5225, 0.891, 0.08, 0.02])%����legendλ��
hold on
if flag_Envelop == 0
%     cdata=cat( 3, 0.48235*ones(size(interx)), 0.40784*ones(size(interx)), 0.93333*ones(size(interx)) );%��ɫ
%     cdata = cat( 3, 0.309803922*ones(size(interx)), 0.580392157*ones(size(interx)), 0.803921569*ones(size(interx)) );%SteelBlue3
    cdata = cat( 3, 0.51765*ones(size(interx)), 0.4392*ones(size(interx)), 1*ones(size(interx)) );
else
    cdata=cat( 3, 0*ones(size(interx)), 0.8078*ones(size(interx)), 0.8196*ones(size(interx)) );%����ʯɫ
%     cdata=cat( 3, 0.603921569*ones(size(interx)), 0.803921569*ones(size(interx)), 0.196078431*ones(size(interx)) ); % OliveDrab3
end
bl = surf(blenvelope, intery, interz, cdata);
if flag_transparency==0
    set(up,'FaceAlpha',0.3);%�����ϰ����ߵ�͸����
    set(bl,'FaceAlpha',0.3);%�����°����ߵ�͸����
    set(mid,'FaceAlpha',1);%���öϲ�ʵ�ֵ�͸����
else
    set(up,'FaceAlpha',1);%�����ϰ����ߵ�͸����
    set(bl,'FaceAlpha',1);%�����°����ߵ�͸����
    set(mid,'FaceAlpha',0.3);%���öϲ�ʵ�ֵ�͸����
end
set(gca,'DataAspectRatio',[3 3 3])%���ø����������ʾ����
set(gca,'fontsize',8,'fontname','Euclid');
set(gca,'linewidth',0.5);
hold on
if flag_Envelop ~= 0
    for i = 2 : length(wellpathlb)
        [wellpathx, wellpathy, wellpathz] = sphere(200);
        wellpathx = wellpathx*20 + wellpathlb(i) + 10;
        wellpathy = wellpathy*30 + wellpathX(i,1);
        wellpathz = wellpathz*30 + wellpathX(i,2);
        cdata=cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );%����ɫ
        surf(wellpathx, wellpathy, wellpathz, cdata);%���ư뾶Ϊ2����
    end
end
hold on
if flag_Envelop ~= 0 & ~isempty(wellpickindex)
    for i=2 : length(wellpickindex)
        [wellpickx, wellpicky, wellpickz] = sphere(200);
        wellpickx = wellpickx*20 + sampleY(wellpickindex(i));
        wellpicky = wellpicky*30 + sampleX(wellpickindex(i),1);
        wellpickz = wellpickz*30 + z_sample(42);
        cdata=cat( 3, 0*ones(size(wellpickx)), 0*ones(size(wellpickx)), 0*ones(size(wellpickx)) );%����ɫ
        surf(wellpickx, wellpicky, wellpickz, cdata);%���ư뾶Ϊ2����
    end
end
% if flag_Envelop ~= 0
%     legend([mid, up, wpath, wpick], {'The reference fault', 'The envelopes', 'The well-path points', 'The well-pick points'})
% else
%     legend([mid, up], {'The reference fault', 'The envelopes'})
% end
% xlim([653900 666180]);%����x�����ʾ��Χ
% ylim([3295990 3321100]);%����y�����ʾ��Χ
ylim([3301390 3314450]);
% zlim([1400 5590]);%����z�����ʾ��Χ
%view([-1,-8,5])
view([-47 23]);
% view([2 15]);
shading interp
light('position',[0,4,1],'style','infinite') 
light('position',[0,2,1],'style','infinite') 
light('position',[0,0,1],'style','infinite') 
xlabel('\it x \rm(m)')
yl = ylabel('\it y \rm(m)');
set(yl,'Rotation',0)
zlabel('\it z \rm(m)')
%light('position',[-1,1,0],'style','infinite')
% if flag_transparency == 0
%     xlabel('(a)');
% else
%     xlabel('(b)');
% end
% if flag_Envelop == 0 & flag_transparency == 0
%     SaveFigure('E:\paper imgs', 'EnvelopInitial_a')
% end
% if flag_Envelop == 0 & flag_transparency == 1
%     SaveFigure('E:\paper imgs', 'EnvelopInitial_b')
% end
% if flag_Envelop == 1 & isempty(wellpickindex) & flag_transparency == 0
%     SaveFigure('E:\paper imgs', 'EnvelopWellpath_a')
% end
% if flag_Envelop == 1 & isempty(wellpickindex) & flag_transparency == 1
%     SaveFigure('E:\paper imgs', 'EnvelopWellpath_b')
% end
% if flag_Envelop == 1 & ~isempty(wellpickindex) & flag_transparency == 0
%     SaveFigure('E:\paper imgs', 'EnvelopWellpathWellpick_a')
% end
% if flag_Envelop == 1 & ~isempty(wellpickindex) & flag_transparency == 1
%     SaveFigure('E:\paper imgs', 'EnvelopWellpathWellpick_b')
% end


figure;
% subfigure1 = subplot( 1, 3, 2 );%��ע�͵����ǽ�����ͼ����һ��ͼ�еĴ���
% set( subfigure1, 'Position', [0.241 0.15541 0.187 0.815]);
% set(gcf,'Units','centimeters','Position',[1 1 10 5]);
cdata = cat( 3, 1*ones(size(interx)), 0.498*ones(size(interx)), 0*ones(size(interx)) );%����ɫ
% cdata=cat( 3, 0.803921569*ones(size(interx)), 0.521568627*ones(size(interx)), 0.247058824*ones(size(interx)) );% ��³ɫ	
mid = surf(interx, intery, interz, cdata);
shading interp
hold on
if flag_Envelop == 0
%     cdata=cat( 3, 0.48235*ones(size(interx)), 0.40784*ones(size(interx)), 0.93333*ones(size(interx)) );%��ɫ 
%     cdata = cat( 3, 0.309803922*ones(size(interx)), 0.580392157*ones(size(interx)), 0.803921569*ones(size(interx)) );%SteelBlue3
    cdata = cat( 3, 0.51765*ones(size(interx)), 0.4392*ones(size(interx)), 1*ones(size(interx)) );
else
    cdata=cat( 3, 0*ones(size(interx)), 0.8078*ones(size(interx)), 0.8196*ones(size(interx)) );%����ʯɫ
%     cdata=cat( 3, 0.803921569*ones(size(interx)), 0.215686275*ones(size(interx)), 0*ones(size(interx)) ); % OrangeRed3
%     cdata=cat( 3, 0.603921569*ones(size(interx)), 0.803921569*ones(size(interx)), 0.196078431*ones(size(interx)) ); % OliveDrab3
end
up = surf(upenvelope, intery, interz, cdata);
hold on
if flag_Envelop ~= 0
    for i=1
        [wellpathx, wellpathy, wellpathz ] = sphere(200);
        wellpathx = wellpathx*20 + wellpathlb(i) + 10;
        wellpathy = wellpathy*30 + wellpathX(i,1);
        wellpathz = wellpathz*30 + wellpathX(i,2);
        cdata = cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );%����ɫ
        wpath = surf(wellpathx, wellpathy, wellpathz, cdata);%���ư뾶Ϊ2����
    end
end
hold on
if flag_Envelop ~= 0 & ~isempty(wellpickindex)
    for i=1
        [wellpickx, wellpicky, wellpickz] = sphere(200);
        wellpickx = wellpickx*20 + sampleY(wellpickindex(i));
        wellpicky = wellpicky*30 + sampleX(wellpickindex(i), 1);
        wellpickz = wellpickz*30 + z_sample(42);
        cdata = cat( 3, 0*ones(size(wellpickx)), 0*ones(size(wellpickx)), 0*ones(size(wellpickx)) );%����ɫ
        wpick = surf(wellpickx, wellpicky, wellpickz, cdata);%���ư뾶Ϊ2����
    end
end
shading interp
% legendposition=legend( 'a fault realization','The envelope adjusted by welldata','wellpath','wellpicks', 4 );
% set(legendposition,'Position', [0.295, 0.79, 0.08, 0.03])%����legendλ��
% set(legendposition,'Position', [0.5225, 0.891, 0.08, 0.02])%����legendλ��
hold on
if flag_Envelop == 0
%     cdata=cat( 3, 0.48235*ones(size(interx)), 0.40784*ones(size(interx)), 0.93333*ones(size(interx)) );%��ɫ
%     cdata = cat( 3, 0.309803922*ones(size(interx)), 0.580392157*ones(size(interx)), 0.803921569*ones(size(interx)) );%SteelBlue3
    cdata = cat( 3, 0.51765*ones(size(interx)), 0.4392*ones(size(interx)), 1*ones(size(interx)) );
else
    cdata=cat( 3, 0*ones(size(interx)), 0.8078*ones(size(interx)), 0.8196*ones(size(interx)) );%����ʯɫ
%     cdata=cat( 3, 0.603921569*ones(size(interx)), 0.803921569*ones(size(interx)), 0.196078431*ones(size(interx)) ); % OliveDrab3
end
bl = surf(blenvelope, intery, interz, cdata);
if flag_transparency==0
    set(up,'FaceAlpha',1);%�����ϰ����ߵ�͸����
    set(bl,'FaceAlpha',1);%�����°����ߵ�͸����
    set(mid,'FaceAlpha',0.3);%���öϲ�ʵ�ֵ�͸����
else
    set(up,'FaceAlpha',0.3);%�����ϰ����ߵ�͸����
    set(bl,'FaceAlpha',0.3);%�����°����ߵ�͸����
    set(mid,'FaceAlpha',1);%���öϲ�ʵ�ֵ�͸����
end
set(gca,'DataAspectRatio',[3 3 3])%���ø����������ʾ����
set(gca,'fontsize',9,'fontname','Euclid');
set(gca,'linewidth',0.5);
hold on
if flag_Envelop ~= 0
    for i = 2 : length(wellpathlb)
        [wellpathx, wellpathy, wellpathz] = sphere(200);
        wellpathx = wellpathx*20 + wellpathlb(i) + 10;
        wellpathy = wellpathy*30 + wellpathX(i,1);
        wellpathz = wellpathz*30 + wellpathX(i,2);
        cdata=cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );%����ɫ
        surf(wellpathx, wellpathy, wellpathz, cdata);%���ư뾶Ϊ2����
    end
end
hold on
if flag_Envelop ~= 0 & ~isempty(wellpickindex)
    for i=2 : length(wellpickindex)
        [wellpickx, wellpicky, wellpickz] = sphere(200);
        wellpickx = wellpickx*20 + sampleY(wellpickindex(i));
        wellpicky = wellpicky*30 + sampleX(wellpickindex(i),1);
        wellpickz = wellpickz*30 + z_sample(42);
        cdata=cat( 3, 0*ones(size(wellpickx)), 0*ones(size(wellpickx)), 0*ones(size(wellpickx)) );%����ɫ
        surf(wellpickx, wellpicky, wellpickz, cdata);%���ư뾶Ϊ2����
    end
end
% if flag_Envelop ~= 0
%     legend([mid, up, wpath, wpick], {'The reference fault', 'The envelopes', 'The well-path points', 'The well-pick points'})
% else
%     legend([mid, up], {'The reference fault', 'The envelopes'})
% end
% xlim([653900 666180]);%����x�����ʾ��Χ
ylim([3301390 3314450]);%����y�����ʾ��Χ
% zlim([1400 5590]);%����z�����ʾ��Χ
%view([-1,-8,5])
view([-47 23]);
% view([2 15]);
shading interp
light('position',[0,4,1],'style','infinite') 
light('position',[0,2,1],'style','infinite') 
light('position',[0,0,1],'style','infinite') 
xlabel('\it x \rm(m)')
yl = ylabel('\it y \rm(m)');
set(yl,'Rotation',0)
zlabel('\it z \rm(m)')

figure;
% subfigure2 = subplot( 1, 2, 2 );%��ע�͵����ǽ�����ͼ����һ��ͼ�еĴ���
% set( subfigure2, 'Position', [0.583828124999999 0.259338313767343 0.171744791666658 0.5965848452508]);
% set(gcf,'Units','centimeters','Position',[1 6 10 5]);
if flag_Envelop == 0 % �����ĵ�ǰ�������ǳ�ʼ������
    fault_line = plot( EvInitial.intersectionfault, IntersectionX( :, 1 ), 'Color', [1 0.498 0], 'linewidth', 1.5);
    hold on
    up_line_init = plot( EvInitial.intersectionup, IntersectionX( :, 1 ), 'Color', [0.51765 0.4392 1], 'linewidth', 1.5);
%     plot( EvInitial.intersectionup, IntersectionX( :, 1 ), 'Color', [0.309803922 0.580392157 0.803921569], 'linewidth', 1.5);%SteelBlue3
    hold on
    bl_line_init = plot( EvInitial.intersectionbl, IntersectionX( :, 1 ), 'Color', [0.51765 0.4392 1], 'linewidth', 1.5);
%     plot( EvInitial.intersectionbl, IntersectionX( :, 1 ), 'Color', [0.309803922 0.580392157 0.803921569], 'linewidth', 1.5);%SteelBlue3
else
    fault_line = plot( Envelop.intersectionfault, IntersectionX( :, 1 ), 'Color', [1 0.498 0], 'linewidth', 1.5);
    hold on
    up_line_init = plot( EvInitial.intersectionup, IntersectionX( :, 1 ), 'Color', [0.51765 0.4392 1], 'linewidth', 1.5);
%     plot( EvInitial.intersectionup, IntersectionX( :, 1 ), 'Color', [0.309803922 0.580392157 0.803921569], 'linewidth', 1.5);%SteelBlue3
    hold on
%     plot( EvWpathWpick.intersectionup, IntersectionX( :, 1 ), 'Color', [0 0.8078 0.8196], 'linewidth', 1.5);
    up_line = plot( Envelop.intersectionup, IntersectionX( :, 1 ), 'Color', [0 0.8078 0.8196], 'linewidth', 1.5);% OliveDrab3
    hold on
%     plot( EvWpathWpick.intersectionbl, IntersectionX( :, 1 ), 'Color', [0 0.8078 0.8196], 'linewidth', 1.5);
    bl_line = plot( Envelop.intersectionbl, IntersectionX( :, 1 ), 'Color', [0 0.8078 0.8196], 'linewidth', 1.5);% OliveDrab3
    hold on
    wpath = plot( wellpathlb, wellpathX(:,1), 'ro','MarkerSize',4,'markerfacecolor','r' )
    hold on
    if ~isempty(wellpickindex)
        wpick = plot( 0.5*(Envelop.sampleup(wellpickindex)+Envelop.samplebl(wellpickindex)), sampleX(wellpickindex,1), 'ko','MarkerSize',4,'markerfacecolor','k' )
    end
    hold on
    bl_line_init = plot( EvInitial.intersectionbl, IntersectionX( :, 1 ), 'Color', [0.51765 0.4392 1], 'linewidth', 1.5);
%     plot( EvInitial.intersectionbl, IntersectionX( :, 1 ), 'Color', [0.309803922 0.580392157 0.803921569], 'linewidth', 1.5);
    hold on
end
if flag_Envelop ~= 0
    legend([fault_line, up_line_init, up_line, wpath, wpick], {'The reference fault', 'The initial envelopes', 'The updated envelopes', 'The well-path points', 'The well-pick points'})
else
    legend([fault_line, up_line_init], {'The reference fault', 'The initial envelopes'})
end

xlabel('\it x \rm(m)')
yl = ylabel('\it y \rm(m)');
set(yl,'Rotation',0)
set(gca,'linewidth',0.5);
set(gca,'DataAspectRatio',[2 3 2])
% set(gca,'DataAspectRatio',[2 3 2])
set(gca,'fontsize',9,'fontname','Euclid');
%set(gca,'xtick',[6.58*10^5,6.585*10^5,6.59*10^5,6.595*10^5,6.6*10^5,6.605*10^5],'ytick',[3.298*10^6,3.302*10^6,3.306*10^6,3.31*10^6]);
axis([min(EvInitial.intersectionbl)-50,max(EvInitial.intersectionup)+50, min(IntersectionX( :, 1 ))-200, max(IntersectionX( :, 1 ))+200]);