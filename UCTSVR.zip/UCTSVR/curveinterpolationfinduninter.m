function [unx,uny,unz] = curveinterpolationfinduninter(xinter, yinter, x, y, z)
n=length(xinter);
l=length(x);
k=0;
for i=1:n
    flag=0;tem=inf;temz=0;
    for j=1:l
%         if xinter(i)==x(j)&&yinter(i)==y(j)
%             flag=1;
%         elseif sqrt((xinter(i)-x(j))^2+(yinter(i)-y(j))^2)<tem
%             tem=sqrt((xinter(i)-x(j))^2+(yinter(i)-y(j))^2);
%             temz=j;
%         end
          if sqrt((xinter(i)-x(j))^2+(yinter(i)-y(j))^2)<tem
            tem=sqrt((xinter(i)-x(j))^2+(yinter(i)-y(j))^2);
            temz=j;
          end
    end
    if flag==0
        k=k+1;
        unx(k)=xinter(i);
        uny(k)=yinter(i);
        unz(k)=z(temz);
    end
end