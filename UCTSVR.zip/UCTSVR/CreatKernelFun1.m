function [KF, T] = CreatKernelFun1(Par, S, Intersectioninput, Un)
% 该函数是用来计算各类核函数
% Par.C是目标函数中的正则化超参数构成的矩阵，其第一行是上界函数对应的正则化超参数，第二行是下界函数对应的正则化超参数
% Par.ker表示核函数的类型
% Par.segema表示核函数中的参数σ
% sampleX是样本点的输入
% unX是待插值点的输入
% wellpickindex是井眼拾取点对应的样本点的索引
% wellpathindex是井眼轨迹点对应的待插值点的索引
tstart = tic;
%想要计时的程序
KF.S2S = svkernel( Par.ker, S.input, S.input, Par.segema );
% 各样本点之间的核函数
KF.Int2S = svkernel( Par.ker, Intersectioninput, S.input, Par.segema );
% 各交线点和各样本点之间的核函数
KF.U2S = svkernel( Par.ker, Un.input, S.input, Par.segema );
% 各待插值点和各样本点之间的核函数
T.kernel = toc(tstart);   % 计算各类核函数的时间