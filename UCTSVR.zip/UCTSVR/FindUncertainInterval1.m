function S = FindUncertainInterval1(S)
% 
% givenquantile2是各断层点的不确定性区间的左端点构成的列向量，givenquantile1是右端点构成的列向量
% S.wellpickindex是各井眼拾取点的索引构成的列向量
%%
num_point = size(S.input,1);
lb = -inf * ones(num_point, 1);
ub = inf * ones(num_point, 1);
givenquantile2 = 0.001 * ones(num_point, 1);
givenquantile1 = 0.999 * ones(num_point, 1);
flag = 1; % 表示样本点的输出服从正态分布
miu = S.output;
segema = 50 * ones(num_point, 1);
if ~isempty(S.wellpickindex)
    segema(S.wellpickindex) = 1 * ones(length(S.wellpickindex), 1);
end
S.ub_UncertainInterval = findquantile(flag, lb, ub, givenquantile1, miu, segema);
S.lb_UncertainInterval = findquantile(flag, lb, ub, givenquantile2, miu, segema);
diffquantile = S.ub_UncertainInterval-S.lb_UncertainInterval;
% max(diffquantile)
% min(diffquantile)