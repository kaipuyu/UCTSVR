%%
clear
close all
clc
load('SurfaceSamplePoint.mat')
load('Envelopinitial.mat');
tstart = tic;
Par.ker = 'rbf';
%Par.segema = 1800;
Par.gama = 5;
Par.flag = 1;
% Par.C是目标函数中的正则化超参数构成的矩阵，其第一行是上界函数对应的正则化超参数，第二行是下界函数对应的正则化超参数
% Par.ker表示核函数的类型
% Par.segema表示核函数中的参数σ
% Par.flag表示样本点输出服从的分布的类型，Par.flag = 1表示正态分布
Par.num_xinter = 460;                    % 将曲面投影到xoy平面上，使用规则网格划分包含投影区域的最小矩形，Par.num_xinter是x方向上的网格点个数
Par.num_yinter = 230;                    % Par.num_yinter是y方向上的网格点个数

S.X = Point.X;                           % 样本点的x坐标
S.Y = Point.Y;                           % 样本点的y坐标
S.input = [S.X S.Y];                     % 由样本点的x坐标和y坐标构成的样本点的输入
S.output = Point.Z;                      % 样本点的原始输出
S.num = length(S.output);                % 样本点的个数
%     S.wellpickindex = [34;41];               % 第34个样本点和第41个样本点为井眼拾取点
S.wellpickindex = [34];                  % 第34个样本点和第41个样本点为井眼拾取点

Xminv = min(S.X);                        % Xminv是整个待插值区域的x坐标起始值
Xmaxv = max(S.X);                        % Xmaxv是整个待插值区域的x坐标的终止
Yminv = min(S.Y);                        % Yminv是整个待插值区域的y坐标的起始值
Ymaxv = max(S.Y);                        % Ymaxv是整个待插值区域的y坐标的终止值

Un.interX = repmat(linspace(min(S.X), max(S.X), Par.num_yinter), [Par.num_xinter 1]);
Un.interY = repmat(linspace(min(S.Y), max(S.Y), Par.num_xinter)', [1 Par.num_yinter]);
Un.X = reshape(Un.interX, 1, Par.num_xinter * Par.num_yinter)';  % 待插值点的x坐标
Un.Y = reshape(Un.interY, 1, Par.num_xinter * Par.num_yinter)';  % 待插值点的y坐标
Un.input = [Un.X, Un.Y];

%     Wpa.index = [93565];
Wpa.index = [83905; 93565];
Wpa.input = Un.input(Wpa.index,:);       % input of well path points
Wpa.num = size(Wpa.input, 1);            % 井眼轨迹点的个数
%     Wpa.lb = [3757+160];                      % lbi in equation (19) for well path points
%     Wpa.ub = [4205];                         % ubi in equation (18) for well path points
Wpa.lb = [3994+80; 3757+160];                      % lbi in equation (19) for well path points
Wpa.ub = [4205; 4205];                         % ubi in equation (18) for well path points
welllb = [Wpa.lb; S.output(S.wellpickindex) - 2*ones(length(S.wellpickindex), 1)];
wellub = [Wpa.ub; S.output(S.wellpickindex) + 2*ones(length(S.wellpickindex), 1)];
% 为了有效集成井眼拾取点，必须给井眼轨迹点的输出加上较小的确定的区间约束。
% 这里把井眼拾取点的上下界约束集成在井眼轨迹点中的上下界约束中

Intersectioninput(:,1) = linspace(Xminv, Xmaxv, Par.num_xinter)';
% 使用CCSVIR生成包络线或使用支持向量回归进行断层重建时，包络线与平面y = S.Y(S.wellpickindex(1))的交线的x坐标
Intersectioninput(:,2) = S.Y(S.wellpickindex(1)) * ones( Par.num_xinter, 1 );
S = FindUncertainInterval1(S);
% S.lb_UncertainInterval是各断层点的不确定性区间（由分位数生成）的左端点构成的列向量，S.ub_UncertainInterval是右端点构成的列向量
MRE_UCTSVR = inf;
set_segema = [2^2, 2^4, 2^6, 2^8, 2^10, 2^12];
set_c1 = [2^10, 2^11, 2^12, 2^13, 2^14, 2^15, 2^16, 2^17, 2^18, 2^19, 2^20];
set_c2 = [2^10, 2^11, 2^12, 2^13, 2^14, 2^15, 2^16, 2^17, 2^18, 2^19, 2^20];
c1_opt = 0;
c2_opt = 0;
segema_opt = 0;
index_i = 0;
for index_segema = 1 : 1 : length(set_segema)
    index_i = index_i + 1;
    Par.segema = set_segema(index_segema);
    [KF] = CreatKernelFun2(Par, S, Wpa, Intersectioninput, Un);
    g.G1 = [ KF.S2S ones(S.num, 1) ];
    g.G2p = [ KF.SW2S(1:S.num + Wpa.num, :) ones(S.num + Wpa.num, 1) ];
    % 只有井眼轨迹点没有井眼拾取点时的G2(这时把初始包络线在样本点处的值作为边界约束)
    g.G2pp = [ KF.SW2S ones(S.num + Wpa.num + length(S.wellpickindex), 1) ];
    % 既有井眼轨迹点又有井眼拾取点时的G2(这时把初始包络线在样本点处的值作为边界约束)
    g.G3 = g.G1;
    k1 = (g.G1')* g.G1;
    index_j = 0;
    for index_c1 = 1 : 1 : length(set_c1)
        c1_cur = set_c1(index_c1);
        index_j = index_j + 1;
        index_k = 0;
        for index_c2 = 1 : 1 : length(set_c2)
            c2_cur = set_c2(index_c2);
            index_k = index_k + 1;
            Par.C = [c1_cur c2_cur; c1_cur c2_cur];
            g.g1 = inv( eye(S.num + 1) + Par.C(1,1) * k1 );
            % g.g1 = g.g1 + 1e-9 * eye( size (g.g1));
            g.g2 = inv( eye(S.num + 1) + Par.C(2,1) * k1 );
            % g.g2 = g.g2 + 1e-9 * eye( size (g.g1));
            h.h1 = g.G1 * g.g1 * g.G1';
            h.h2p = g.G1 * g.g1 * g.G2p';    % 只有井眼轨迹点没有井眼拾取点时的h2
            h.h2pp = g.G1 * g.g1 * g.G2pp';  % 既有井眼轨迹点又有井眼拾取点时的h2
            h.h3p = g.G2p * g.g1 * g.G2p';   % 只有井眼轨迹点没有井眼拾取点时的h3
            h.h3pp = g.G2pp * g.g1 * g.G2pp';% 既有井眼轨迹点又有井眼拾取点时的h3
            h.h4 = g.G1 * g.g2 * g.G1';
            h.h5p = g.G1 * g.g2 * g.G2p';    % 只有井眼轨迹点没有井眼拾取点时的h5
            h.h5pp = g.G1 * g.g2 * g.G2pp';  % 既有井眼轨迹点又有井眼拾取点时的h5
            h.h6 = g.G1 * g.g2 * g.G3';
            h.h7p = g.G2p * g.g2 * g.G2p';   % 只有井眼轨迹点没有井眼拾取点时的h7
            h.h7pp = g.G2pp * g.g2 * g.G2pp';% 既有井眼轨迹点又有井眼拾取点时的h7
            h.h8p = g.G2p * g.g2 * g.G3';    % 只有井眼轨迹点没有井眼拾取点时的h8
            h.h8pp = g.G2pp * g.g2 * g.G3';  % 既有井眼轨迹点又有井眼拾取点时的h8
            h.h9 = g.G3 * g.g2 * g.G3';
            H1 = [h.h1 -h.h2pp; -h.h2pp' h.h3pp];
            % 上包络线对应的二次规划矩阵H1
            q1 = S.ub_UncertainInterval;
            q2 = S.lb_UncertainInterval;
            Q1 = [-q1'+Par.C(1,1)*q1'*h.h1, [EvInitial.sampleup',wellub']-Par.C(1,1)*q1'*h.h2pp];
            % 上包络线对应的二次规划的一次项系数向量
            num_well = length(welllb);
            vlb1 = zeros ( 2*S.num + num_well, 1 ); 
            % vlb1是对偶问题（11）式中拉格朗日乘子α1i和α*1i的下界
            vub1 = [ Par.C(2,2) * ones(S.num, 1); inf * ones(S.num+num_well, 1) ];
             % vub1是对偶问题（11）式中拉格朗日乘子α1i和α*1i的上界
            [alpha1, ~, ~] = quadprog(H1, Q1, [], [], [], [], vlb1, vub1);
            coefficientUpEn = g.g1 * ( Par.C(1,1) * g.G1' * q1 + g.G1' * alpha1(1 : S.num) - g.G2pp' * alpha1(S.num+1 : length(alpha1))) ;
            EvWpathWpick.up = [ KF.U2S ones(size(KF.U2S, 1), 1) ] * coefficientUpEn;
            EvWpathWpick.upenvelope = reshape(EvWpathWpick.up, Par.num_xinter, Par.num_yinter);
            EvWpathWpick.sampleup = g.G1 * coefficientUpEn;
            EvWpathWpick.intersectionup = [ KF.Int2S ones(size(KF.Int2S, 1), 1) ] * coefficientUpEn;
            H2 = [h.h4 -h.h5pp h.h6; -h.h5pp' h.h7pp -h.h8pp; h.h6' -h.h8pp' h.h9];
            % 下包络线对应的二次规划矩阵H2
            Q2 = [-q2'-Par.C(2,1)*q2'*h.h4, [-EvInitial.samplebl', -welllb']+Par.C(2,1)*q2'*h.h5pp, EvWpathWpick.sampleup'-Par.gama*ones(1,length(EvWpathWpick.sampleup))-Par.C(2,1)*q2'*h.h6];
            % 下包络线对应的二次规划的一次项系数向量
            vlb2 = zeros ( 3 * S.num + num_well, 1 ); 
            % vlb2是对偶问题（12）式中拉格朗日乘子α2i，α*2i，α3i的下界
            vub2 = [ Par.C(2, 2) * ones(S.num, 1); inf * ones(2 * S.num + num_well, 1) ]; 
            % vub2是对偶问题（12）式中拉格朗日乘子α2i，α*2i，α3i的上界
            [alpha2, ~, ~] = quadprog(H2, Q2, [], [], [], [], vlb2, vub2);
            coefficientBlEn = g.g2 * ( Par.C(2,1)*g.G1'*q2 - g.G1'*alpha2(1 : S.num) + g.G2pp'*alpha2(S.num+1 : 2*S.num+num_well) - g.G3'*alpha2(2*S.num+num_well+1 : length(alpha2))) ;
            EvWpathWpick.bl = [ KF.U2S ones(size(KF.U2S, 1), 1) ] * coefficientBlEn;
            EvWpathWpick.blenvelope = reshape(EvWpathWpick.bl, Par.num_xinter, Par.num_yinter);
            EvWpathWpick.samplebl = g.G1 * coefficientBlEn;
            EvWpathWpick.intersectionbl = [ KF.Int2S ones(size(KF.Int2S, 1), 1) ] * coefficientBlEn;
            EvWpathWpick.Faultfun = 0.5*(EvWpathWpick.bl + EvWpathWpick.up);
            EvWpathWpick.Fault = reshape(EvWpathWpick.Faultfun, Par.num_xinter, Par.num_yinter);
            EvWpathWpick.intersectionFault = 0.5*(EvWpathWpick.intersectionbl + EvWpathWpick.intersectionup);
            num_point = length(Sur.X);
            MRE_cur = sum( abs( ( EvWpathWpick.Faultfun - Sur.Z ) ./ Sur.Z ) ) / num_point;
            Matrix_MRE(index_i, index_j, index_k) = MRE_cur;
            if MRE_cur<MRE_UCTSVR
                MRE_UCTSVR = MRE_cur;
                c1_opt = c1_cur;
                c2_opt = c2_cur;
                segema_opt = Par.segema;
            end
        end
    end
end

Par.segema = segema_opt;
[KF] = CreatKernelFun2(Par, S, Wpa, Intersectioninput, Un);
g.G1 = [ KF.S2S ones(S.num, 1) ];
g.G2p = [ KF.SW2S(1:S.num + Wpa.num, :) ones(S.num + Wpa.num, 1) ];
% 只有井眼轨迹点没有井眼拾取点时的G2(这时把初始包络线在样本点处的值作为边界约束)
g.G2pp = [ KF.SW2S ones(S.num + Wpa.num + length(S.wellpickindex), 1) ];
% 既有井眼轨迹点又有井眼拾取点时的G2(这时把初始包络线在样本点处的值作为边界约束)
g.G3 = g.G1;
k1 = (g.G1')* g.G1;
Par.C = [c1_opt c2_opt; c1_opt c2_opt];
g.g1 = inv( eye(S.num + 1) + Par.C(1,1) * k1 );
g.g2 = inv( eye(S.num + 1) + Par.C(2,1) * k1 );
h.h1 = g.G1 * g.g1 * g.G1';
h.h2p = g.G1 * g.g1 * g.G2p';    % 只有井眼轨迹点没有井眼拾取点时的h2
h.h2pp = g.G1 * g.g1 * g.G2pp';  % 既有井眼轨迹点又有井眼拾取点时的h2
h.h3p = g.G2p * g.g1 * g.G2p';   % 只有井眼轨迹点没有井眼拾取点时的h3
h.h3pp = g.G2pp * g.g1 * g.G2pp';% 既有井眼轨迹点又有井眼拾取点时的h3
h.h4 = g.G1 * g.g2 * g.G1';
h.h5p = g.G1 * g.g2 * g.G2p';    % 只有井眼轨迹点没有井眼拾取点时的h5
h.h5pp = g.G1 * g.g2 * g.G2pp';  % 既有井眼轨迹点又有井眼拾取点时的h5
h.h6 = g.G1 * g.g2 * g.G3';
h.h7p = g.G2p * g.g2 * g.G2p';   % 只有井眼轨迹点没有井眼拾取点时的h7
h.h7pp = g.G2pp * g.g2 * g.G2pp';% 既有井眼轨迹点又有井眼拾取点时的h7
h.h8p = g.G2p * g.g2 * g.G3';    % 只有井眼轨迹点没有井眼拾取点时的h8
h.h8pp = g.G2pp * g.g2 * g.G3';  % 既有井眼轨迹点又有井眼拾取点时的h8
h.h9 = g.G3 * g.g2 * g.G3';
H1 = [h.h1 -h.h2pp; -h.h2pp' h.h3pp];
% 上包络线对应的二次规划矩阵H1
q1 = S.ub_UncertainInterval;
q2 = S.lb_UncertainInterval;
Q1 = [-q1'+Par.C(1,1)*q1'*h.h1, [EvInitial.sampleup',wellub']-Par.C(1,1)*q1'*h.h2pp];
% 上包络线对应的二次规划的一次项系数向量
num_well = length(welllb);
vlb1 = zeros ( 2*S.num + num_well, 1 ); 
% vlb1是对偶问题（11）式中拉格朗日乘子α1i和α*1i的下界
vub1 = [ Par.C(2,2) * ones(S.num, 1); inf * ones(S.num+num_well, 1) ];
% vub1是对偶问题（11）式中拉格朗日乘子α1i和α*1i的上界
[alpha1, ~, ~] = quadprog(H1, Q1, [], [], [], [], vlb1, vub1);
coefficientUpEn = g.g1 * ( Par.C(1,1) * g.G1' * q1 + g.G1' * alpha1(1 : S.num) - g.G2pp' * alpha1(S.num+1 : length(alpha1))) ;
EvWpathWpick.up = [ KF.U2S ones(size(KF.U2S, 1), 1) ] * coefficientUpEn;
EvWpathWpick.upenvelope = reshape(EvWpathWpick.up, Par.num_xinter, Par.num_yinter);
EvWpathWpick.sampleup = g.G1 * coefficientUpEn;
EvWpathWpick.intersectionup = [ KF.Int2S ones(size(KF.Int2S, 1), 1) ] * coefficientUpEn;
H2 = [h.h4 -h.h5pp h.h6; -h.h5pp' h.h7pp -h.h8pp; h.h6' -h.h8pp' h.h9];
% 下包络线对应的二次规划矩阵H2
Q2 = [-q2'-Par.C(2,1)*q2'*h.h4, [-EvInitial.samplebl', -welllb']+Par.C(2,1)*q2'*h.h5pp, EvWpathWpick.sampleup'-Par.gama*ones(1,length(EvWpathWpick.sampleup))-Par.C(2,1)*q2'*h.h6];
% 下包络线对应的二次规划的一次项系数向量
vlb2 = zeros ( 3 * S.num + num_well, 1 ); 
% vlb2是对偶问题（12）式中拉格朗日乘子α2i，α*2i，α3i的下界
vub2 = [ Par.C(2, 2) * ones(S.num, 1); inf * ones(2 * S.num + num_well, 1) ]; 
% vub2是对偶问题（12）式中拉格朗日乘子α2i，α*2i，α3i的上界
[alpha2, ~, ~] = quadprog(H2, Q2, [], [], [], [], vlb2, vub2);
coefficientBlEn = g.g2 * ( Par.C(2,1)*g.G1'*q2 - g.G1'*alpha2(1 : S.num) + g.G2pp'*alpha2(S.num+1 : 2*S.num+num_well) - g.G3'*alpha2(2*S.num+num_well+1 : length(alpha2))) ;
EvWpathWpick.bl = [ KF.U2S ones(size(KF.U2S, 1), 1) ] * coefficientBlEn;
EvWpathWpick.blenvelope = reshape(EvWpathWpick.bl, Par.num_xinter, Par.num_yinter);
EvWpathWpick.samplebl = g.G1 * coefficientBlEn;
EvWpathWpick.intersectionbl = [ KF.Int2S ones(size(KF.Int2S, 1), 1) ] * coefficientBlEn;
EvWpathWpick.Faultfun = 0.5*(EvWpathWpick.bl + EvWpathWpick.up);
EvWpathWpick.Fault = reshape(EvWpathWpick.Faultfun, Par.num_xinter, Par.num_yinter);
EvWpathWpick.intersectionFault = 0.5*(EvWpathWpick.intersectionbl + EvWpathWpick.intersectionup);
num_point = length(Sur.X);
MRE_opt = sum( abs( ( EvWpathWpick.Faultfun - Sur.Z ) ./ Sur.Z ) ) / num_point;
RMSD_CCSVIR = sqrt( sum( ( EvWpathWpick.up - Sur.Z ).^2 )  / num_point ) + sqrt(sum( ( EvWpathWpick.bl - Sur.Z ).^2 ) / num_point );
T.total = toc(tstart);       
save('opt_par.mat', 'segema_opt', 'c1_opt', 'c2_opt', 'set_segema', 'set_c1', 'set_c2', 'Matrix_MRE')
%%
close all
load('opt_par.mat')
index_opt_segema = find(set_segema == segema_opt);
index_opt_c1 = find(set_c1 == c1_opt);
index_opt_c2 = find(set_c2 == c2_opt);
Matrix_opt_segema = reshape(Matrix_MRE(index_opt_segema, :, :), length(set_c1), length(set_c2))';

Un.interc1 = repmat(set_c1, [length(set_c2) 1]);
Un.interc2 = repmat(set_c2', [1 length(set_c1)]);
Un.c1 = reshape(Un.interc1, 1, length(set_c1) * length(set_c2))';  % 待插值点的x坐标
Un.c2 = reshape(Un.interc2, 1, length(set_c1) * length(set_c2))';  % 待插值点的y坐标
cdata = cat( 3, 1*ones(length(set_c2), length(set_c1)), 0.498*ones(length(set_c2), length(set_c1)), 0*ones(length(set_c2), length(set_c1)) );
mid = surf(Un.interc1, Un.interc2, Matrix_opt_segema, cdata);
xlabel('\it c_1 \rm')
ylabel('\it c_2 \rm')
zl = zlabel('\it MRE \rm');
set(zl, 'Rotation', 0)
xlim = ([min(set_c1)-50 max(set_c1)+50]);
hold on
plot3(Un.c1, Un.c2, reshape(Matrix_opt_segema, 1, length(set_c1) * length(set_c2)), 'ko', 'MarkerFaceColor', 'k')
% plot3(set_c1, c2_opt*ones(length(set_c1)), Matrix_MRE(index_opt_segema, :, index_opt_c2), 'ro', 'MarkerFaceColor', 'r')
% plot3(c1_opt*ones(length(set_c1)), set_c2, reshape(Matrix_MRE(index_opt_segema, index_opt_c1, :), 1, length(set_c2)), 'bo', 'MarkerFaceColor', 'b')
view(19.8, 22.8)

C = [0.51765, 0.4392, 1; 0, 0.8078, 0.8196; 1, 0.498, 0];
figure
plot(set_c1, Matrix_MRE(index_opt_segema, :, index_opt_c2), '-.o','color', C(1,:), 'MarkerFaceColor', C(1,:), 'LineWidth', 1.5)
xlabel('\it c_1 \rm')
y1 = ylabel('\it MRE \rm');
set(y1, 'Rotation', 0)
figure
plot(set_c2, reshape(Matrix_MRE(index_opt_segema, index_opt_c1, :), 1, length(set_c2)), '-.o','color', C(2,:), 'MarkerFaceColor', C(2,:), 'LineWidth', 1.5)
xlabel('\it c_2 \rm')
ylabel('\it MRE \rm')
y1 = ylabel('\it MRE \rm');
set(y1, 'Rotation', 0)
figure
plot(set_segema, Matrix_MRE(:, index_opt_c1, index_opt_c2), '-.o','color', C(3,:), 'MarkerFaceColor', C(3,:), 'LineWidth', 1.5)
xlabel('\it \sigma \rm')
y1 = ylabel('\it MRE \rm');
set(y1, 'Rotation', 0)
%%
save('EvWpathWpick_UCTSVR.mat', 'EvWpathWpick', 'Par', 'S', 'Point', 'Wpa', 'Un', 'EvInitial', 'Intersectioninput')
save('Time_UCTSVR_Well.mat', 'T')
%% 画使用井眼轨迹点和井眼拾取点调整后的包络线
Initial_flag = 0;
% Initial_flag表示包络线类型，Initial_flag==1表示没有使用井数据调整的初始包络线，Initial_flag==0表示使用井数据调整后的包络线
PlotEnvelope(Par, S, Point, Wpa, Un, EvWpathWpick, EvInitial, Intersectioninput, Initial_flag)