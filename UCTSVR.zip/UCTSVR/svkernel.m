function k = svkernel(ker, u, v, d)
%SVKERNEL kernel for Support Vector Methods
%
%  Usage: k = svkernel(ker, u, v, d)
%
%  Parameters: ker - kernel type
%              u,v - kernel arguments
% d - Parameter of kernel function.If ker is a gaussian kernel function,then d is the width parameter of the function.If ker is polynomial, then d is the order.
%
%  Values for ker: 'linear'  -
%                  'poly'    - p1 is degree of polynomial
%                  'rbf'     - p1 is width of rbfs (sigma)
%                  'sigmoid' - p1 is scale, p2 is offset
%                  'spline'  -
%                  'bspline' - p1 is degree of bspline
%                  'fourier' - p1 is degree
%                  'erfb'    - p1 is width of rbfs (sigma)
%              
%  Author: Steve Gunn (srg@ecs.soton.ac.uk)

  if (nargin < 1) % check correct number of arguments
     help svkernel
  else
    % could check for correct number of args in here
    % but will slow things down further
    switch lower(ker)
        case 'linear'
            k = u * v';
        case 'poly'
            k1 = u * v';
            k = (k1 + ones( size( k1 ) )).^d;
        case 'rbf'
            [nx,mx]=size(u);
            for i=1:mx
                A(:,:,i) = ( repmat( u(:,i), [1,size(v,1)] ) - repmat( v(:,i)', [nx,1] ) ).^2;
            end
            k = exp( sum(A,3)/ (-2*d^2) );
        otherwise
            k = u * v';
    end
  end