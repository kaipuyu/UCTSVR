%%
clear
close all
clc
load('SurfaceSamplePoint.mat')
for count = 1 : 1
    tstart = tic;
    Par.C = [3461000 1000; 3461000 1000];
%     Par.C = [2200 1200; 2200 1200];
    Par.ker = 'rbf';
    Par.segema = 900;
    Par.gama = 1.5;
    Par.flag = 1;
    % Par.C是目标函数中的正则化超参数构成的矩阵，其第一行是上界函数对应的正则化超参数，第二行是下界函数对应的正则化超参数
    % Par.ker表示核函数的类型
    % Par.segema表示核函数中的参数σ
    % Par.flag表示样本点输出服从的分布的类型，Par.flag = 1表示正态分布
    Par.num_xinter = 460;                    % 将曲面投影到xoy平面上，使用规则网格划分包含投影区域的最小矩形，Par.num_xinter是x方向上的网格点个数
    Par.num_yinter = 230;                    % Par.num_yinter是y方向上的网格点个数

    S.X = Point.X;                           % 样本点的x坐标
    S.Y = Point.Y;                           % 样本点的y坐标
    S.input = [S.X S.Y];                     % 由样本点的x坐标和y坐标构成的样本点的输入
    S.output = Point.Z;                      % 样本点的原始输出
    S.num = length(S.output);                % 样本点的个数
    S.wellpickindex = [];
   
    Xminv = min(S.X);                                  % Xminv是整个待插值区域的x坐标起始值
    Xmaxv = max(S.X);                                  % Xmaxv是整个待插值区域的x坐标的终止
    Yminv = min(S.Y);                                  % Yminv是整个待插值区域的y坐标的起始值
    Ymaxv = max(S.Y);                                  % Ymaxv是整个待插值区域的y坐标的终止值

    Un.interX = repmat(linspace(min(S.X), max(S.X), Par.num_yinter), [Par.num_xinter 1]);
    Un.interY = repmat(linspace(min(S.Y), max(S.Y), Par.num_xinter)', [1 Par.num_yinter]);
    Un.X = reshape(Un.interX, 1, Par.num_xinter * Par.num_yinter)';  % 待插值点的x坐标
    Un.Y = reshape(Un.interY, 1, Par.num_xinter * Par.num_yinter)';  % 待插值点的y坐标
    Un.input = [Un.X, Un.Y];  

    Intersectioninput(:,1) = linspace(Xminv, Xmaxv, Par.num_xinter)';
    % 使用UCTSVR生成包络线时，包络线与平面y = S.Y(S.wellpickindex(1))的交线的x坐标
    Intersectioninput(:,2) = S.Y(34) * ones( Par.num_xinter, 1 );
    % 使用UCTSVR生成包络线时，包络线与平面y = S.Y(S.wellpickindex(1))的交线的y坐标

    [KF, ~] = CreatKernelFun1(Par, S, Intersectioninput, Un);
    T.kernel(count) = toc(tstart);
    tstart = tic;
    S = FindUncertainInterval1(S);
    % S.lb_UncertainInterval是各断层点的不确定性区间（由分位数生成）的左端点构成的列向量，S.ub_UncertainInterval是右端点构成的列向量
    g.G1 = [ KF.S2S ones(S.num, 1) ];
    g.G2 = g.G1;
    g.G3 = g.G1;
    k1 = (g.G1')* g.G1;
    g.g1 = inv( eye(S.num + 1) + Par.C(1,1) * k1 );
    % g.g1 = g.g1 + 1e-9 * eye( size (g.g1));
    g.g2 = inv( eye(S.num + 1) + Par.C(2,1) * k1 );
    % g.g2 = g.g2 + 1e-9 * eye( size (g.g1));
    h.h1 = g.G1 * g.g1 * g.G1';
    h.h4 = g.G1 * g.g2 * g.G1';
    h.h5 = g.G1 * g.g2 * g.G2';
    h.h6 = g.G1 * g.g2 * g.G3';
    h.h7 = g.G2 * g.g2 * g.G2';
    h.h8 = g.G2 * g.g2 * g.G3';
    h.h9 = g.G3 * g.g2 * g.G3';
    H1 = [h.h1 -h.h1; -h.h1' h.h1];
    % 上包络线对应的二次规划矩阵H1
    % 下包络线对应的二次规划矩阵H2
    q1 = S.ub_UncertainInterval;
    q2 = S.lb_UncertainInterval;
    Q1 = [-q1'+Par.C(1,1)*q1'*h.h1, S.output'+390*ones(1, length(S.output))-Par.C(1,1)*q1'*h.h1];
    % 上包络线对应的二次规划的一次项系数向量
    vlb1 = zeros ( 2 * S.num, 1 ); 
    % vlb1是对偶问题（11）式中拉格朗日乘子α1i的下界
    vub1 = [ Par.C(1,2) * ones(S.num, 1); inf * ones(S.num, 1) ];
     % vub1是对偶问题（11）式中拉格朗日乘子α1i的上界
    [alpha1, ~, ~] = quadprog(H1, Q1, [], [], [], [], vlb1, vub1);  
    T.sloveQppUP(count) = toc(tstart);
    tstart = tic;
    coefficientUpEn = g.g1 * ( Par.C(1,1) * g.G1' * q1 + g.G1' * alpha1(1 : S.num) - g.G1' * alpha1(S.num+1 : length(alpha1))) ;
    EvInitial.up = [ KF.U2S ones(size(KF.U2S, 1), 1) ] * coefficientUpEn;
    EvInitial.upenvelope = reshape(EvInitial.up, Par.num_xinter, Par.num_yinter);
    EvInitial.sampleup = g.G1 * coefficientUpEn;
    EvInitial.intersectionup = [ KF.Int2S ones(size(KF.Int2S, 1), 1) ] * coefficientUpEn;
    T.getUPEnvelop(count) = toc(tstart);
    tstart = tic;
    H2 = [h.h4 -h.h5 h.h6; -h.h5' h.h7 -h.h8; h.h6' -h.h8' h.h9];
    % 下包络线对应的二次规划矩阵H2
    % Q2 = [q2'-Par.C(2,1)*q2'*h.h4, -(S.output'-390*ones(1, length(S.output)))+Par.C(2,1)*q2'*h.h5, S.output'+390*ones(1, length(S.output))-0*ones(1,length(S.output))-Par.C(2,1)*q2'*h.h6];
    Q2 = [q2'-Par.C(2,1)*q2'*h.h4, -(S.output'-390*ones(1, length(S.output)))+Par.C(2,1)*q2'*h.h5, EvInitial.sampleup'-0*ones(1,length(S.output))-Par.C(2,1)*q2'*h.h6];
    % 下包络线对应的二次规划的一次项系数向量
    vlb2 = zeros ( 3 * S.num, 1 ); 
    % vlb2是对偶问题（12）式中拉格朗日乘子α2i，α*2i，α3i的下界
    vub2 = [ Par.C(2, 2) * ones(S.num, 1); inf * ones(2 * S.num, 1) ];  
    [alpha2, ~, ~] = quadprog(H2, Q2, [], [], [], [], vlb2, vub2);
    T.sloveQppbl(count) = toc(tstart);
    tstart = tic;
    coefficientBlEn = g.g2 * ( Par.C(2,1)*g.G1'*q2 - g.G1'*alpha2(1 : S.num) + g.G2'*alpha2(S.num+1 : 2*S.num) - g.G3'*alpha2(2*S.num+1 : length(alpha2))) ;
    EvInitial.bl = [ KF.U2S ones(size(KF.U2S, 1), 1) ] * coefficientBlEn;
    EvInitial.blenvelope = reshape(EvInitial.bl, Par.num_xinter, Par.num_yinter);
    EvInitial.samplebl = g.G1 * coefficientBlEn;
    EvInitial.intersectionbl = [ KF.Int2S ones(size(KF.Int2S, 1), 1) ] * coefficientBlEn;
    T.getBLEnvelop(count) = toc(tstart);
    tstart = tic;
    EvInitial.Faultfun = 0.5*(EvInitial.bl + EvInitial.up);
    EvInitial.Fault = reshape(EvInitial.Faultfun, Par.num_xinter, Par.num_yinter);
    EvInitial.intersectionFault = 0.5*(EvInitial.intersectionbl + EvInitial.intersectionup);
    T.getReferenceFault(count) = toc(tstart);
end
T.kernel = T.kernel';
T.sloveQppUP = T.sloveQppUP';
T.sloveQppbl = T.sloveQppbl';
T.getUPEnvelop = T.getUPEnvelop';
T.getBLEnvelop = T.getBLEnvelop';
T.getReferenceFault = T.getReferenceFault';
T.sloveQpp = T.sloveQppUP + T.sloveQppbl;
T.getEnvelop = T.getUPEnvelop + T.getBLEnvelop + T.getReferenceFault;
T.total = T.kernel + T.sloveQpp + T.getEnvelop;
num_point = length(Sur.X);
RMSE_UCTSVR = sqrt( sum( ( EvInitial.Faultfun - Sur.Z ).^2 ) / num_point );
%%
save Envelopinitial.mat EvInitial
save('EvInitial_UCTSVR.mat', 'EvInitial')
save('Time_UCTSVR_initial', 'T')
%% 画初始包络线
Initial_flag = 1;
% Initial_flag表示包络线类型，Initial_flag==1表示没有使用井数据调整的初始包络线，Initial_flag==0表示使用井数据调整后的包络线
PlotEnvelope(Par, S, Point, [], Un, EvInitial, EvInitial, Intersectioninput, Initial_flag)