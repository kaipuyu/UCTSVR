function PlotEnvelope(P, S, Point, W, U, Ev, InitialEv, Jiaoxianinput, Initial_flag)
%%
figure
cdata = cat( 3, 1*ones(P.num_xinter, P.num_yinter), 0.498*ones(P.num_xinter, P.num_yinter), 0*ones(P.num_xinter, P.num_yinter) );
mid = surf(U.interX, U.interY, Ev.Fault, cdata);
shading interp
hold on
if Initial_flag == 1 % 所画的当前包络线是否是初始包络线的标志
    cdata=cat( 3, 0.51765*ones(P.num_xinter, P.num_yinter), 0.4392*ones(P.num_xinter, P.num_yinter), 1*ones(P.num_xinter, P.num_yinter) );
    up = surf(U.interX, U.interY, Ev.upenvelope, cdata);
    hold on
    cdata=cat( 3, 0.51765*ones(P.num_xinter, P.num_yinter), 0.4392*ones(P.num_xinter, P.num_yinter), 1*ones(P.num_xinter, P.num_yinter) );
    bl = surf(U.interX, U.interY, Ev.blenvelope, cdata);
    legend([mid, up], {'The reference fault', 'The envelopes'})
else
    cdata=cat( 3, 0*ones(P.num_xinter, P.num_yinter), 0.8078*ones(P.num_xinter, P.num_yinter), 0.8196*ones(P.num_xinter, P.num_yinter) );
    up = surf(U.interX, U.interY, Ev.upenvelope, cdata);
    hold on
    for i=1
        [wellpathx,wellpathy,wellpathz]=sphere(200);
        wellpathx = wellpathx*20 + W.input(i,1);
        wellpathy = wellpathy*20 + W.input(i,2);
        wellpathz = wellpathz*20 + W.lb(i) - 10;
        cdata=cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );
        wpath = surf(wellpathx, wellpathy, wellpathz, cdata);
    end
    hold on
    if ~isempty(S.wellpickindex)
        for i=1
            [wellpickx,wellpicky,wellpickz] = sphere(200);
            wellpickx = wellpickx*20 + S.X(S.wellpickindex(i));
            wellpicky = wellpicky*20 + S.Y(S.wellpickindex(1));
            wellpickz = wellpickz*20 + S.output(S.wellpickindex(i));
            cdata=cat( 3, 0*ones(size(wellpickx)), 0*ones(size(wellpickx)), 0*ones(size(wellpickx)) );
            wpick = surf(wellpickx, wellpicky, wellpickz, cdata);
            hold on
        end
    end
    cdata = cat( 3, 0*ones(P.num_xinter, P.num_yinter), 0.8078*ones(P.num_xinter, P.num_yinter), 0.8196*ones(P.num_xinter, P.num_yinter) );%绿松石色
    bl = surf(U.interX, U.interY, Ev.blenvelope, cdata);
    hold on
    for i = 2:W.num
        [wellpathx,wellpathy,wellpathz] = sphere(200);
        wellpathx = wellpathx*20 + W.input(i,1);
        wellpathy = wellpathy*20 + W.input(i,2);
        wellpathz = wellpathz*20 + W.lb(i)-10;
        cdata=cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );
        wpath = surf(wellpathx, wellpathy, wellpathz, cdata);
        hold on
    end
    if ~isempty(S.wellpickindex)
        for i=2:length(S.wellpickindex)
            [wellpickx,wellpicky,wellpickz] = sphere(200);
            wellpickx = wellpickx*20 + S.X(S.wellpickindex(i));
            wellpicky = wellpicky*20 + S.Y(S.wellpickindex(1));
            wellpickz = wellpickz*20 + S.output(S.wellpickindex(i));
            cdata=cat( 3, 0*ones(size(wellpickx)), 0*ones(size(wellpickx)), 0*ones(size(wellpickx)) );
            wpick = surf(wellpickx, wellpicky, wellpickz, cdata);
        end
    end
    legend([mid, up, wpath, wpick], {'The reference fault', 'The envelopes', 'The well-path points', 'The well-pick points'}, 'FontSize', 6)
end
% plot3(Point.X, Point.Y, Point.Z, 'r.');
shading interp
set(up,'FaceAlpha',0.3);
set(bl,'FaceAlpha',0.3);
set(mid,'FaceAlpha',1);
set(gca,'DataAspectRatio',[2 2 2])
set(gca,'fontsize',9,'fontname','Euclid');
set(gca,'linewidth',0.5);
zlim([3469.75259 4454.9138])
ylim([min(S.Y)-50 max(S.Y)+50])
xlim([min(S.X)-50 max(S.X)+50])
% view(11,27);
view([2 15]);
shading interp
light('position',[0,4,1],'style','infinite') 
light('position',[0,2,1],'style','infinite') 
light('position',[0,0,1],'style','infinite') 
xlabel('\it x \rm')
yl = ylabel('\it y \rm');
% set(yl,'Rotation',0)
zl = zlabel('\it z \rm');
set(zl, 'Rotation', 0)

figure
cdata = cat( 3, 1*ones(P.num_xinter, P.num_yinter), 0.498*ones(P.num_xinter, P.num_yinter), 0*ones(P.num_xinter, P.num_yinter) );
mid = surf(U.interX, U.interY, Ev.Fault, cdata);
shading interp
hold on
if Initial_flag == 1 % 所画的当前包络线是否是初始包络线的标志
    cdata=cat( 3, 0.51765*ones(P.num_xinter, P.num_yinter), 0.4392*ones(P.num_xinter, P.num_yinter), 1*ones(P.num_xinter, P.num_yinter) );
    up = surf(U.interX, U.interY, Ev.upenvelope, cdata);
    hold on
    cdata=cat( 3, 0.51765*ones(P.num_xinter, P.num_yinter), 0.4392*ones(P.num_xinter, P.num_yinter), 1*ones(P.num_xinter, P.num_yinter) );
    bl = surf(U.interX, U.interY, Ev.blenvelope, cdata);
    legend([mid, up], {'The reference fault', 'The envelopes'})
else
    cdata=cat( 3, 0*ones(P.num_xinter, P.num_yinter), 0.8078*ones(P.num_xinter, P.num_yinter), 0.8196*ones(P.num_xinter, P.num_yinter) );
    up = surf(U.interX, U.interY, Ev.upenvelope, cdata);
    hold on
    for i=1
        [wellpathx,wellpathy,wellpathz]=sphere(200);
        wellpathx = wellpathx*20 + W.input(i,1);
        wellpathy = wellpathy*20 + W.input(i,2);
        wellpathz = wellpathz*20 + W.lb(i) - 10;
        cdata=cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );
        wpath = surf(wellpathx, wellpathy, wellpathz, cdata);
    end
    hold on
    if ~isempty(S.wellpickindex)
        for i=1
            [wellpickx,wellpicky,wellpickz] = sphere(200);
            wellpickx = wellpickx*20 + S.X(S.wellpickindex(i));
            wellpicky = wellpicky*20 + S.Y(S.wellpickindex(1));
            wellpickz = wellpickz*20 + S.output(S.wellpickindex(i));
            cdata=cat( 3, 0*ones(size(wellpickx)), 0*ones(size(wellpickx)), 0*ones(size(wellpickx)) );
            wpick = surf(wellpickx, wellpicky, wellpickz, cdata);
            hold on
        end
    end
    cdata = cat( 3, 0*ones(P.num_xinter, P.num_yinter), 0.8078*ones(P.num_xinter, P.num_yinter), 0.8196*ones(P.num_xinter, P.num_yinter) );%绿松石色
    bl = surf(U.interX, U.interY, Ev.blenvelope, cdata);
    hold on
    for i = 2:W.num
        [wellpathx,wellpathy,wellpathz] = sphere(200);
        wellpathx = wellpathx*20 + W.input(i,1);
        wellpathy = wellpathy*20 + W.input(i,2);
        wellpathz = wellpathz*20 + W.lb(i)-10;
        cdata=cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );
        wpath = surf(wellpathx, wellpathy, wellpathz, cdata);
        hold on
    end
    if ~isempty(S.wellpickindex)
        for i=2:length(S.wellpickindex)
            [wellpickx,wellpicky,wellpickz] = sphere(200);
            wellpickx = wellpickx*20 + S.X(S.wellpickindex(i));
            wellpicky = wellpicky*20 + S.Y(S.wellpickindex(1));
            wellpickz = wellpickz*20 + S.output(S.wellpickindex(i));
            cdata=cat( 3, 0*ones(size(wellpickx)), 0*ones(size(wellpickx)), 0*ones(size(wellpickx)) );
            wpick = surf(wellpickx, wellpicky, wellpickz, cdata);
        end
    end
    legend([mid, up, wpath, wpick], {'The reference fault', 'The envelopes', 'The well-path points', 'The well-pick points'}, 'FontSize', 6)
end
% plot3(Point.X, Point.Y, Point.Z, 'r.');
shading interp
set(up,'FaceAlpha',0.3);
set(bl,'FaceAlpha',0.3);
set(mid,'FaceAlpha',1);
set(gca,'DataAspectRatio',[2 2 2])
set(gca,'fontsize',9,'fontname','Euclid');
set(gca,'linewidth',0.5);
zlim([3469.75259 4454.9138])
ylim([min(S.Y)-50 max(S.Y)+50])
xlim([min(S.X)-50 max(S.X)+50])
% view(11,27);
view(-11.3, 1.1);
shading interp
%light('position',[0,4,1],'style','infinite') 
light('position',[0,-20,1],'style','infinite') 
light('position',[0,0,1],'style','infinite')
xlabel('\it x \rm')
yl = ylabel('\it y \rm');
% set(yl,'Rotation',0)
zl = zlabel('\it z \rm');
set(zl, 'Rotation', 0)

% figure
% cdata = cat( 3, 1*ones(P.num_xinter, P.num_yinter), 0.498*ones(P.num_xinter, P.num_yinter), 0*ones(P.num_xinter, P.num_yinter) );
% mid = surf(U.interX, U.interY, Ev.Fault, cdata);
% shading interp
% hold on
% if Initial_flag == 1 % 所画的当前包络线是否是初始包络线的标志
%     cdata=cat( 3, 0.51765*ones(P.num_xinter, P.num_yinter), 0.4392*ones(P.num_xinter, P.num_yinter), 1*ones(P.num_xinter, P.num_yinter) );
%     up = surf(U.interX, U.interY, Ev.upenvelope, cdata);
%     hold on
%     cdata=cat( 3, 0.51765*ones(P.num_xinter, P.num_yinter), 0.4392*ones(P.num_xinter, P.num_yinter), 1*ones(P.num_xinter, P.num_yinter) );
%     bl = surf(U.interX, U.interY, Ev.blenvelope, cdata);
%     legend([mid, up], {'The reference fault', 'The envelopes'})
% else
%     cdata=cat( 3, 0*ones(P.num_xinter, P.num_yinter), 0.8078*ones(P.num_xinter, P.num_yinter), 0.8196*ones(P.num_xinter, P.num_yinter) );
%     up = surf(U.interX, U.interY, Ev.upenvelope, cdata);
%     hold on
%     for i=1
%         [wellpathx,wellpathy,wellpathz]=sphere(200);
%         wellpathx = wellpathx*20 + W.input(i,1);
%         wellpathy = wellpathy*20 + W.input(i,2);
%         wellpathz = wellpathz*20 + W.lb(i) - 10;
%         cdata=cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );
%         wpath = surf(wellpathx, wellpathy, wellpathz, cdata);
%     end
%     hold on
%     if ~isempty(S.wellpickindex)
%         for i=1
%             [wellpickx,wellpicky,wellpickz] = sphere(200);
%             wellpickx = wellpickx*20 + S.X(S.wellpickindex(i));
%             wellpicky = wellpicky*20 + S.Y(S.wellpickindex(1));
%             wellpickz = wellpickz*20 + S.output(S.wellpickindex(i));
%             cdata=cat( 3, 0*ones(size(wellpickx)), 0*ones(size(wellpickx)), 0*ones(size(wellpickx)) );
%             wpick = surf(wellpickx, wellpicky, wellpickz, cdata);
%             hold on
%         end
%     end
%     cdata = cat( 3, 0*ones(P.num_xinter, P.num_yinter), 0.8078*ones(P.num_xinter, P.num_yinter), 0.8196*ones(P.num_xinter, P.num_yinter) );%绿松石色
%     bl = surf(U.interX, U.interY, Ev.blenvelope, cdata);
%     hold on
%     for i = 2:W.num
%         [wellpathx,wellpathy,wellpathz] = sphere(200);
%         wellpathx = wellpathx*20 + W.lb(i)-10;
%         wellpathy = wellpathy*20 + W.input(i,2);
%         wellpathz = wellpathz*20 + W.lb(i) - 10;
%         cdata=cat( 3, 1*ones(size(wellpathx)), 0*ones(size(wellpathx)), 0*ones(size(wellpathx)) );
%         wpath = surf(wellpathx, wellpathy, wellpathz, cdata);
%         hold on
%     end
%     if ~isempty(S.wellpickindex)
%         for i=2:length(S.wellpickindex)
%             [wellpickx,wellpicky,wellpickz] = sphere(200);
%             wellpickx = wellpickx*20 + S.X(S.wellpickindex(i));
%             wellpicky = wellpicky*20 + S.Y(S.wellpickindex(1));
%             wellpickz = wellpickz*20 + S.output(S.wellpickindex(i));
%             cdata=cat( 3, 0*ones(size(wellpickx)), 0*ones(size(wellpickx)), 0*ones(size(wellpickx)) );
%             wpick = surf(wellpickx, wellpicky, wellpickz, cdata);
%         end
%     end
%     legend([mid, up, wpath, wpick], {'The reference fault', 'The initial envelopes', 'The well-path points', 'The well-pick points'})
% end
% % plot3(Point.X, Point.Y, Point.Z, 'r.');
% shading interp
% set(up,'FaceAlpha',1);
% set(bl,'FaceAlpha',1);
% set(mid,'FaceAlpha',0.3);
% set(gca,'DataAspectRatio',[2 2 2])
% set(gca,'fontsize',9,'fontname','Euclid');
% set(gca,'linewidth',0.5);
% zlim([3469.75259 4454.9138])
% ylim([min(S.Y)-50 max(S.Y)+50])
% xlim([min(S.X)-50 max(S.X)+50])
% % view(11,27);
% view(-4.73, 2.08);
% shading interp
% %light('position',[0,4,1],'style','infinite') 
% light('position',[0,-20,1],'style','infinite') 
% light('position',[0,0,1],'style','infinite')
% xlabel('\it x \rm')
% yl = ylabel('\it y \rm');
% % set(yl,'Rotation',0)
% zl = zlabel('\it z \rm');
% set(zl, 'Rotation', 0)

figure
if Initial_flag == 1 % 所画的当前包络线是否是初始包络线的标志
    fault_line = plot( Jiaoxianinput( :, 1 ), Ev.intersectionFault, 'Color', [1 0.498 0], 'linewidth', 1.5);
    hold on
    up_line_init = plot( Jiaoxianinput( :, 1 ), Ev.intersectionup, 'Color', [0.51765 0.4392 1], 'linewidth', 1.5);
    hold on
    bl_line_init = plot( Jiaoxianinput( :, 1 ), Ev.intersectionbl, 'Color', [0.51765 0.4392 1], 'linewidth', 1.5);
    legend([fault_line, up_line_init], {'The reference fault', 'The initial envelopes'})
else
    fault_line = plot( Jiaoxianinput( :, 1 ), Ev.intersectionFault, 'Color', [1 0.498 0], 'linewidth', 1.5);
    hold on
%     up_line_init = plot( Jiaoxianinput( :, 1 ), InitialEv.intersectionup, 'Color', [0.51765 0.4392 1], 'linewidth', 1.5);
%     hold on
    up_line = plot( Jiaoxianinput( :, 1 ), Ev.intersectionup, 'Color', [0 0.8078 0.8196], 'linewidth', 1.5);
    hold on
    wpath = plot( W.input(:,1), W.lb, 'ro','MarkerSize',4,'markerfacecolor','r' );
    hold on
    bl_line = plot( Jiaoxianinput( :, 1 ), Ev.intersectionbl, 'Color', [0 0.8078 0.8196], 'linewidth', 1.5);
    hold on
    if ~isempty(S.wellpickindex)
        wpick = plot( S.input(S.wellpickindex,1), S.output(S.wellpickindex), 'ko','MarkerSize',4,'markerfacecolor','k' );
    end
    hold on
%     bl_line_init = plot( Jiaoxianinput( :, 1 ), InitialEv.intersectionbl, 'Color', [0.51765 0.4392 1], 'linewidth', 1.5);
%     hold on
%     legend([fault_line, up_line_init, up_line, wpath, wpick], {'The reference fault', 'The initial envelopes', 'The updated envelopes', 'The well-path points', 'The well-pick points'}, 'FontSize', 4)
    legend([fault_line, up_line, wpath, wpick], {'The reference fault', 'The envelopes', 'The well-path points', 'The well-pick points'}, 'FontSize', 6)
end
set(gca,'linewidth',1.5);
set(gca,'DataAspectRatio',[1 1 1])
set(gca,'fontsize',9,'fontname','Euclid');
set(gca,'linewidth',0.5);
%set(gca,'xtick',[6.58*10^5,6.585*10^5,6.59*10^5,6.595*10^5,6.6*10^5,6.605*10^5],'ytick',[3.298*10^6,3.302*10^6,3.306*10^6,3.31*10^6]);
axis([min(Jiaoxianinput( :, 1 ))-200, max(Jiaoxianinput( :, 1 ))+200, min(InitialEv.intersectionbl)-50,max(InitialEv.intersectionup)+50]);
% set(gca,'DataAspectRatio',[1 3.5 2])
% xlabel('(c)');
xlabel('\it x \rm')
yl = ylabel('\it z \rm');
set(yl,'Rotation',0)
% SaveFigure('C:\Users\dell\Desktop\paper imgs', 'FaultRealizationbyCCSVRWGR_b')